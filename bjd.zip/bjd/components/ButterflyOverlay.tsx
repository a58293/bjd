
import React from 'react';

const ButterflyOverlay: React.FC<any> = () => {
  return null;
};

export default ButterflyOverlay;
